#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define nx 129

int main()
{
    int i;
    double *x, *y;
    FILE*datoscuerda=fopen("cond_ini_cuerda.dat","r");
    double delta_x=0.05;
    double delta_t = 1/delta_x;
    float c = 250;
    double r = c*delta_t/delta_x;
    int t = 1;
    

    x= malloc(nx*sizeof(double));
    y= malloc(nx*sizeof(double));

/*importar el archivo de datos*/

    for (i=0; i<nx; i++) 
    {
        fscanf(datoscuerda, "%lf %lf\n", &x[i], &y[i]);
        printf("%lf\n", x[i]);

    }
    
    fclose(datoscuerda);
    return 0;


FILE*datoscuerda1=fopen("datoscuerda.dat","w");

double*u_initial=malloc(nx*sizeof(double));
double*u_present=malloc(nx*sizeof(double));
double*u_future=malloc(nx*sizeof(double));

/*condiciones de frontera*/
for(i=1; i<nx-1; i++)
{
    u_future[i] = u_initial[i]+(pow(r,2)/2.0)*(u_initial[i+1] -2.0*u_initial[i]+u_initial[i-1]);

}

for(i=1;i<nx;i++)
{
    u_initial[i]=y[i];
}


/*siguientes iteraciones*/
int j;

for (j=0; j<t; j++)
{
    for (i=1; i<nx-1; i++)
    {
        u_future[i] = (2.0*(1.0-pow(r,2)))*u_present[i]-u_initial[i]+(pow(r,2))*(u_present[i+1]+u_present[i-1]);
    }
}

/*guardar las variables para ir avanzando*/

int k;
	for(k=1;k<nx;k++)
{
		u_initial[k]=u_present[k];
		u_present[k]=u_future[k];
				
}



if(j==t/2 | j==t/4 | j==t/8)
{
		
    for(i=0;i<nx;i++)
    {	
	fprintf(datoscuerda1,"%f",u_future[i]);
    } 

    fprintf(datoscuerda1,"\n");
}


}

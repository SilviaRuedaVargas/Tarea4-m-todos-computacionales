#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define nx 129

int main()
{
    int i;
    double *x, *y;
    double delta_x=0.05;
    double delta_t = 1/delta_x;
    float c = 250;
    double r = c*delta_t/delta_x;
    int t = 1;
    double pi=3.1415;
    double l_cuerda=0.64;

    

    x= malloc(nx*sizeof(double));
    y= malloc(nx*sizeof(double));


FILE*datoscuerdapert1=fopen("datoscuerdapert.dat","w");

double*upert_initial=malloc(nx*sizeof(double));
double*upert_present=malloc(nx*sizeof(double));
double*upert_future=malloc(nx*sizeof(double));

/*condiciones iniciales*/
for(i=0;i<nx;i++)
{
upert_inicial[i]=0;
upert_present[i]=0;
}


/*siguientes iteraciones*/
for (i=1;i<nx-1;i++){
	upert_present[i]=upert_inicial[i] + pow(r,2)*0.5*(upert_inicial[i+1]-2*upert_inicial[i]+upert_inicial[i-1]);}

for(j=1;j<t;j++)
{
	
    for (i=1;i<nx-1;i++)
    {
        upert_siguiente[i]=2*(1-pow(r,2))*u[i] - upert_inicial[i] + pow(r,2)*(upert_present[i+1]+ upert_present[i-1]);
		
    }

		upert_present[nx-1]=sin((2*pi*c/l_cuerda)*(j*delta_t));
}

/*guardar las variables para ir avanzando*/
		
int k;
for(k=0;k<nx;k++)
{
upert_inicial[k]=upert_present[k];
upert_present[k]=upert_future[k];
				
}


if(j==t/2 | j==t/4 | j==t/8)
	{
		
		for(i=0;i<nx;i++)
		{	
			fprintf(datoscuerda1,"%f",upert_future[i]);
		} 

		fprintf(datoscuerda1,"\n");
	}


}



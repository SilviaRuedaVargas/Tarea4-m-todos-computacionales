import matplotlib.pyplot as plt
import numpy as np

cond_ini_cuerda=np.genfromtxt("cond_ini_cuerda.dat")
datoscuerda=np.genfromtxt("datoscuerda.dat")
datoscuerdapert=np.gentfromtxt("datoscuerdapert.dat")
x=cond_ini_cuerda[:,0]
u=cond_ini_cuerda[:,1]
upert=datoscuerdapert[:,1]

plt.plot(x,u)
plt.title("Cuerda sin perturbar")
plt.show

plt.plot(x,upert)
plt.title("Cuerda perturbada")
plt.show

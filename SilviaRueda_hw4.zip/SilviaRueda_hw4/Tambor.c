#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define nx 101

double delta_x = u_initial[1,1]-u_initial[0,0];
double r = c*delta_t/delta_x;
double t=1;


for(j=1;j<nx;j++)
{
    for (i=1; i<nx; i++)
    {
        u_future[i,j] = u_initia[i,j] + ((pow(r,2))/2.0) * (u_initial[i+1,j+1] - 2.0 * u_initial[i,j] + u_initial[i-1,j-1]);
    }
}

for(j=0;j<nx;j++)
{
    for(i=0; i<nx; i++)
    {
        u_past[i,j] = u_initial[i,j];
        u_present[i,j] = u_future[i,j];
    }
}

float*t2 = malloc(nx*nx*sizeof(double));
float*t4 = malloc(nx*nx*sizeof(double));
float*t8 = malloc(nx*nx*sizeof(double));


int k;
for (k=0; k<t; k++)
{
    for(i=1;i<nx;j++)
    {
        for (j=1; j<nx;j++)
        {
            u_future[i,j] = (2.0*(1.0-(pow(r,2))))*u_present[i,j] - u_past[i,j] + (pow(r,2))*(u_present[i+1,j+1] +  u_present[i-1,j-1]);
        }
    }
}


for(i=0; i<nx;i++)
{
    for(j=0; j<nx; j++)
    {
        t2[i,j] = u_future[i,j];
        t4[i,j] = u_future[i,j];
        t8[i,j] = u_future[i,j];
    }
}



}

